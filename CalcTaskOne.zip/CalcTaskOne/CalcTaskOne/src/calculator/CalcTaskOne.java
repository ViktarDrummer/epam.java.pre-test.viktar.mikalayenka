package calculator;

import java.util.Scanner;

public class CalcTaskOne {
	
	private static Scanner read;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	       read = new Scanner(System.in);

	       double x=0; /* first number */
	       double y=0; /*second number*/
	       String operator;
	  
	       

	       System.out.print("First number: ");
	       x = read.nextDouble();
	       System.out.print("Operator: ");
	       operator = read.next(); 
	       System.out.print("Second number: ");
	       y = read.nextDouble();
	    	 
	       
	        if (operator.equals("*")){
	            System.out.println("= " + (x * y));
	        }
	     
	        if (operator.equals("/")){
	            System.out.println("= " + (x / y));
	        }
	       
	        if (operator.equals("+")){
	            System.out.println("= " + (x + y));
	        }
	     
	        if (operator.equals("-")){
	            System.out.println("= " + (x - y));
	        }
	         
	    } 
	
}

